﻿
namespace LogicGatesAvalonia.Models.DesiginationSymbols
{
    public class BaseDesiginationSymbol
    {
        protected string desiginationName = "";

        public string GetDesiginationName()
        {
            return this.desiginationName;
        }
    }
}
