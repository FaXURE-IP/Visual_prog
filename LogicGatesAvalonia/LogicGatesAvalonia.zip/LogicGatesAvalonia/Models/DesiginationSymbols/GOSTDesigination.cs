﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogicGatesAvalonia.Models.DesiginationSymbols
{
    public class GOSTDesigination : BaseDesiginationSymbol
    {
        public GOSTDesigination() 
        {
            this.desiginationName = "GOST";
        }
    }
}
