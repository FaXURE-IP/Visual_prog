﻿
namespace LogicGatesAvalonia.Models.ElectricCircuit
{
    public enum CiruitStateType
    {
        DefaultState,
        WaitingInputConnectionState
    }
}
