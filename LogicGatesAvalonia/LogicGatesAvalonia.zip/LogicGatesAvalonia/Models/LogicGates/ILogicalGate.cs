﻿namespace LogicGatesAvalonia.Models
{
    public interface ILogicalGate
    {
        public void ProcessSignal();
    }
}
