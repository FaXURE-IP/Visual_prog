﻿using ReactiveUI;

namespace LogicGatesAvalonia.ViewModels
{
    public class ViewModelBase : ReactiveObject
    {
    }
}
